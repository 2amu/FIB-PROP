package Drivers;

import Presentacio.Controladors.CtrlPresentacio;

public class DriverCtrlPresentacio {
    public static void main(String[] args) {
        CtrlPresentacio.iniPresentacio();
    }
}